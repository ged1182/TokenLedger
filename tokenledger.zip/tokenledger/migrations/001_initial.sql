-- TokenLedger: LLM Cost Analytics Schema
-- Optimized for Postgres 14+ (works with Supabase, Neon, etc.)

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Main table for LLM API calls
CREATE TABLE IF NOT EXISTS llm_usage (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    
    -- Timing
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    duration_ms INTEGER, -- API call duration
    
    -- Request identification
    request_id VARCHAR(255), -- Your internal request/trace ID
    user_id VARCHAR(255), -- Your user identifier
    org_id VARCHAR(255), -- Organization/tenant ID
    environment VARCHAR(50) DEFAULT 'production', -- production, staging, dev
    
    -- LLM Provider details
    provider VARCHAR(50) NOT NULL, -- openai, anthropic, cohere, etc.
    model VARCHAR(100) NOT NULL, -- gpt-4, claude-3-opus, etc.
    endpoint VARCHAR(100), -- chat, completions, embeddings, etc.
    
    -- Token usage
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens INTEGER GENERATED ALWAYS AS (prompt_tokens + completion_tokens) STORED,
    
    -- Cost (in USD, stored as cents for precision)
    prompt_cost_cents NUMERIC(12, 4) NOT NULL DEFAULT 0,
    completion_cost_cents NUMERIC(12, 4) NOT NULL DEFAULT 0,
    total_cost_cents NUMERIC(12, 4) GENERATED ALWAYS AS (prompt_cost_cents + completion_cost_cents) STORED,
    
    -- Request metadata
    temperature NUMERIC(3, 2),
    max_tokens INTEGER,
    stream BOOLEAN DEFAULT FALSE,
    
    -- Custom tags for filtering
    tags JSONB DEFAULT '{}',
    
    -- Error tracking
    status VARCHAR(20) DEFAULT 'success', -- success, error, timeout
    error_type VARCHAR(100),
    error_message TEXT,
    
    -- Optional: store prompts for debugging (disable in prod for privacy)
    prompt_hash VARCHAR(64), -- SHA256 of prompt for deduplication analysis
    cache_hit BOOLEAN DEFAULT FALSE
);

-- Indexes for common query patterns
CREATE INDEX idx_llm_usage_created_at ON llm_usage (created_at DESC);
CREATE INDEX idx_llm_usage_user_id ON llm_usage (user_id) WHERE user_id IS NOT NULL;
CREATE INDEX idx_llm_usage_org_id ON llm_usage (org_id) WHERE org_id IS NOT NULL;
CREATE INDEX idx_llm_usage_model ON llm_usage (model);
CREATE INDEX idx_llm_usage_provider ON llm_usage (provider);
CREATE INDEX idx_llm_usage_environment ON llm_usage (environment);
CREATE INDEX idx_llm_usage_status ON llm_usage (status);

-- Composite index for time-range queries with filters
CREATE INDEX idx_llm_usage_time_model ON llm_usage (created_at DESC, model);
CREATE INDEX idx_llm_usage_time_user ON llm_usage (created_at DESC, user_id);

-- GIN index for JSONB tags
CREATE INDEX idx_llm_usage_tags ON llm_usage USING GIN (tags);

-- Materialized view for daily aggregates (refresh periodically)
CREATE MATERIALIZED VIEW IF NOT EXISTS llm_usage_daily AS
SELECT 
    DATE_TRUNC('day', created_at) AS day,
    provider,
    model,
    user_id,
    org_id,
    environment,
    COUNT(*) AS request_count,
    SUM(prompt_tokens) AS total_prompt_tokens,
    SUM(completion_tokens) AS total_completion_tokens,
    SUM(total_tokens) AS total_tokens,
    SUM(total_cost_cents) AS total_cost_cents,
    AVG(duration_ms) AS avg_duration_ms,
    PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY duration_ms) AS p95_duration_ms,
    COUNT(*) FILTER (WHERE status = 'error') AS error_count
FROM llm_usage
GROUP BY 
    DATE_TRUNC('day', created_at),
    provider,
    model,
    user_id,
    org_id,
    environment;

CREATE UNIQUE INDEX idx_llm_usage_daily_unique ON llm_usage_daily (day, provider, model, user_id, org_id, environment);

-- Function to refresh the daily materialized view
CREATE OR REPLACE FUNCTION refresh_llm_usage_daily()
RETURNS void AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY llm_usage_daily;
END;
$$ LANGUAGE plpgsql;

-- Model pricing table (easily updatable)
CREATE TABLE IF NOT EXISTS llm_model_pricing (
    id SERIAL PRIMARY KEY,
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    prompt_cost_per_1k NUMERIC(10, 6) NOT NULL, -- Cost per 1000 tokens
    completion_cost_per_1k NUMERIC(10, 6) NOT NULL,
    effective_date DATE NOT NULL DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    
    UNIQUE(provider, model, effective_date)
);

-- Insert current pricing (as of Jan 2025)
INSERT INTO llm_model_pricing (provider, model, prompt_cost_per_1k, completion_cost_per_1k) VALUES
    -- OpenAI
    ('openai', 'gpt-4o', 0.0025, 0.01),
    ('openai', 'gpt-4o-mini', 0.00015, 0.0006),
    ('openai', 'gpt-4-turbo', 0.01, 0.03),
    ('openai', 'gpt-4', 0.03, 0.06),
    ('openai', 'gpt-3.5-turbo', 0.0005, 0.0015),
    ('openai', 'o1', 0.015, 0.06),
    ('openai', 'o1-mini', 0.003, 0.012),
    ('openai', 'o3-mini', 0.0011, 0.0044),
    -- Anthropic
    ('anthropic', 'claude-3-5-sonnet-20241022', 0.003, 0.015),
    ('anthropic', 'claude-3-5-haiku-20241022', 0.0008, 0.004),
    ('anthropic', 'claude-3-opus-20240229', 0.015, 0.075),
    ('anthropic', 'claude-3-sonnet-20240229', 0.003, 0.015),
    ('anthropic', 'claude-3-haiku-20240307', 0.00025, 0.00125)
ON CONFLICT (provider, model, effective_date) DO NOTHING;

-- Alerts configuration table
CREATE TABLE IF NOT EXISTS llm_alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Alert conditions
    metric VARCHAR(50) NOT NULL, -- daily_cost, hourly_cost, error_rate, latency_p95
    threshold NUMERIC(12, 4) NOT NULL,
    comparison VARCHAR(10) NOT NULL, -- gt, lt, gte, lte
    
    -- Scope
    user_id VARCHAR(255), -- NULL = all users
    org_id VARCHAR(255), -- NULL = all orgs
    model VARCHAR(100), -- NULL = all models
    
    -- Notification
    webhook_url TEXT,
    email VARCHAR(255),
    
    -- Status
    enabled BOOLEAN DEFAULT TRUE,
    last_triggered_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- API Keys for the dashboard
CREATE TABLE IF NOT EXISTS api_keys (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key_hash VARCHAR(64) NOT NULL UNIQUE, -- SHA256 of the key
    key_prefix VARCHAR(12) NOT NULL, -- First 8 chars for identification
    name VARCHAR(255),
    permissions JSONB DEFAULT '["read", "write"]',
    last_used_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Helper function to calculate cost
CREATE OR REPLACE FUNCTION calculate_llm_cost(
    p_provider VARCHAR,
    p_model VARCHAR,
    p_prompt_tokens INTEGER,
    p_completion_tokens INTEGER
) RETURNS TABLE (prompt_cost NUMERIC, completion_cost NUMERIC) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (p_prompt_tokens / 1000.0) * lmp.prompt_cost_per_1k,
        (p_completion_tokens / 1000.0) * lmp.completion_cost_per_1k
    FROM llm_model_pricing lmp
    WHERE lmp.provider = p_provider 
      AND lmp.model = p_model
      AND lmp.effective_date <= CURRENT_DATE
    ORDER BY lmp.effective_date DESC
    LIMIT 1;
END;
$$ LANGUAGE plpgsql;

-- View for current costs summary
CREATE OR REPLACE VIEW llm_cost_summary AS
SELECT 
    DATE_TRUNC('day', created_at) AS day,
    provider,
    model,
    COUNT(*) AS requests,
    SUM(total_tokens) AS tokens,
    SUM(total_cost_cents) / 100.0 AS cost_usd,
    AVG(duration_ms) AS avg_latency_ms
FROM llm_usage
WHERE created_at > NOW() - INTERVAL '30 days'
GROUP BY DATE_TRUNC('day', created_at), provider, model
ORDER BY day DESC, cost_usd DESC;
