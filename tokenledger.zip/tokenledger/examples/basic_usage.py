"""
TokenLedger Basic Usage Example

This example shows how to instrument OpenAI and Anthropic
to automatically track LLM costs.
"""

import os
from tokenledger import TokenLedger, patch_openai, patch_anthropic

# Initialize TokenLedger
# Use your Postgres/Supabase connection string
ledger = TokenLedger(
    database_url=os.environ.get("DATABASE_URL", "postgresql://tokenledger:tokenledger@localhost:5432/tokenledger"),
    default_environment="development",
    default_tags={"app": "my-ai-app"},
)

# Patch the SDKs - this is all you need!
patch_openai(ledger)
patch_anthropic(ledger)

# Now use OpenAI normally
from openai import OpenAI
client = OpenAI()

response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What's the capital of France?"}
    ],
    user="user_123",  # This gets tracked!
)

print(f"Response: {response.choices[0].message.content}")
print(f"Tokens used: {response.usage.total_tokens}")

# Check the dashboard at http://localhost:3000 to see the cost!

# You can also query costs programmatically
from datetime import datetime, timedelta

summary = ledger.get_cost_summary(
    start=datetime.utcnow() - timedelta(hours=1),
)

print(f"\nLast hour stats:")
print(f"  Requests: {summary.total_requests}")
print(f"  Tokens: {summary.total_tokens}")
print(f"  Cost: ${summary.total_cost_usd:.4f}")

# Don't forget to flush on shutdown
ledger.shutdown()
