"""Anthropic SDK interceptor for automatic usage tracking."""

from __future__ import annotations

import functools
import time
import logging
from typing import Any, Callable, TYPE_CHECKING

from tokenledger.models import UsageRecord, Status, hash_prompt

if TYPE_CHECKING:
    from tokenledger.client import TokenLedger

logger = logging.getLogger("tokenledger.anthropic")

_original_create: Callable | None = None
_original_acreate: Callable | None = None
_original_stream: Callable | None = None
_original_astream: Callable | None = None
_patched = False


def patch_anthropic(
    ledger: TokenLedger | None = None,
    *,
    track_prompts: bool = False,
    user_id_extractor: Callable[[dict], str | None] | None = None,
    org_id_extractor: Callable[[dict], str | None] | None = None,
    tags_extractor: Callable[[dict], dict[str, Any]] | None = None,
) -> None:
    """
    Patch the Anthropic SDK to automatically track all API calls.
    
    Args:
        ledger: TokenLedger instance. If None, uses the singleton instance.
        track_prompts: If True, store a hash of the prompt for deduplication analysis.
        user_id_extractor: Function to extract user_id from request kwargs.
        org_id_extractor: Function to extract org_id from request kwargs.
        tags_extractor: Function to extract custom tags from request kwargs.
    
    Usage:
        from tokenledger import TokenLedger, patch_anthropic
        
        ledger = TokenLedger(database_url="postgresql://...")
        patch_anthropic(ledger)
        
        # Now all Anthropic calls are automatically tracked
        from anthropic import Anthropic
        client = Anthropic()
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            messages=[{"role": "user", "content": "Hello!"}]
        )
    """
    global _patched, _original_create, _original_acreate, _original_stream, _original_astream
    
    if _patched:
        logger.warning("Anthropic SDK already patched")
        return
    
    try:
        from anthropic.resources import messages as anthropic_messages
    except ImportError:
        raise ImportError(
            "anthropic package not installed. Install with: pip install tokenledger[anthropic]"
        )
    
    from tokenledger.client import TokenLedger as TL
    
    if ledger is None:
        ledger = TL.get_instance()
        if ledger is None:
            raise ValueError(
                "No TokenLedger instance provided and no singleton instance exists. "
                "Create a TokenLedger instance first."
            )
    
    # Store originals
    _original_create = anthropic_messages.Messages.create
    _original_acreate = anthropic_messages.AsyncMessages.create
    _original_stream = getattr(anthropic_messages.Messages, "stream", None)
    _original_astream = getattr(anthropic_messages.AsyncMessages, "stream", None)
    
    def _extract_usage_info(
        kwargs: dict[str, Any],
        response: Any,
        duration_ms: int,
        error: Exception | None = None,
    ) -> UsageRecord:
        """Extract usage information from request/response."""
        model = kwargs.get("model", "unknown")
        
        # Extract user/org/tags
        user_id = user_id_extractor(kwargs) if user_id_extractor else None
        org_id = org_id_extractor(kwargs) if org_id_extractor else None
        tags = tags_extractor(kwargs) if tags_extractor else {}
        
        # Anthropic-specific metadata
        if kwargs.get("metadata"):
            if kwargs["metadata"].get("user_id"):
                user_id = user_id or kwargs["metadata"]["user_id"]
        
        # Add metadata tags
        if kwargs.get("tools"):
            tags["has_tools"] = True
        if kwargs.get("system"):
            tags["has_system"] = True
        
        # Handle error case
        if error:
            return UsageRecord(
                provider="anthropic",
                model=model,
                prompt_tokens=0,
                completion_tokens=0,
                duration_ms=duration_ms,
                user_id=user_id,
                org_id=org_id,
                tags=tags,
                endpoint="messages",
                temperature=kwargs.get("temperature"),
                max_tokens=kwargs.get("max_tokens"),
                stream=kwargs.get("stream", False),
                status=Status.ERROR,
                error_type=type(error).__name__,
                error_message=str(error)[:500],
                prompt_hash=hash_prompt(kwargs.get("messages", [])) if track_prompts else None,
            )
        
        # Extract token usage from response
        usage = getattr(response, "usage", None)
        prompt_tokens = getattr(usage, "input_tokens", 0) if usage else 0
        completion_tokens = getattr(usage, "output_tokens", 0) if usage else 0
        
        # Get actual model used
        actual_model = getattr(response, "model", model)
        
        # Check for cache hits (Anthropic's prompt caching)
        cache_creation = getattr(usage, "cache_creation_input_tokens", 0) if usage else 0
        cache_read = getattr(usage, "cache_read_input_tokens", 0) if usage else 0
        cache_hit = cache_read > 0
        
        if cache_creation or cache_read:
            tags["cache_creation_tokens"] = cache_creation
            tags["cache_read_tokens"] = cache_read
        
        return UsageRecord(
            provider="anthropic",
            model=actual_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=duration_ms,
            user_id=user_id,
            org_id=org_id,
            tags=tags,
            endpoint="messages",
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
            stream=kwargs.get("stream", False),
            status=Status.SUCCESS,
            prompt_hash=hash_prompt(kwargs.get("messages", [])) if track_prompts else None,
            cache_hit=cache_hit,
        )
    
    @functools.wraps(_original_create)
    def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        error = None
        response = None
        
        try:
            response = _original_create(self, *args, **kwargs)
            return response
        except Exception as e:
            error = e
            raise
        finally:
            duration_ms = int((time.time() - start_time) * 1000)
            try:
                record = _extract_usage_info(kwargs, response, duration_ms, error)
                ledger.log(record)
            except Exception as log_error:
                logger.warning(f"Failed to log Anthropic usage: {log_error}")
    
    @functools.wraps(_original_acreate)
    async def patched_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        error = None
        response = None
        
        try:
            response = await _original_acreate(self, *args, **kwargs)
            return response
        except Exception as e:
            error = e
            raise
        finally:
            duration_ms = int((time.time() - start_time) * 1000)
            try:
                record = _extract_usage_info(kwargs, response, duration_ms, error)
                ledger.log(record)
            except Exception as log_error:
                logger.warning(f"Failed to log Anthropic usage: {log_error}")
    
    # Apply patches
    anthropic_messages.Messages.create = patched_create
    anthropic_messages.AsyncMessages.create = patched_acreate
    
    _patched = True
    logger.info("Anthropic SDK patched for usage tracking")


def unpatch_anthropic() -> None:
    """Remove the Anthropic SDK patch."""
    global _patched, _original_create, _original_acreate, _original_stream, _original_astream
    
    if not _patched:
        return
    
    try:
        from anthropic.resources import messages as anthropic_messages
    except ImportError:
        return
    
    if _original_create:
        anthropic_messages.Messages.create = _original_create
    if _original_acreate:
        anthropic_messages.AsyncMessages.create = _original_acreate
    
    _patched = False
    _original_create = None
    _original_acreate = None
    logger.info("Anthropic SDK patch removed")
