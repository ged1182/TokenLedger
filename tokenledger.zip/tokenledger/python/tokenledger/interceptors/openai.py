"""OpenAI SDK interceptor for automatic usage tracking."""

from __future__ import annotations

import functools
import time
import logging
from typing import Any, Callable, TYPE_CHECKING

from tokenledger.models import UsageRecord, Status, hash_prompt

if TYPE_CHECKING:
    from tokenledger.client import TokenLedger

logger = logging.getLogger("tokenledger.openai")

_original_create: Callable | None = None
_original_acreate: Callable | None = None
_patched = False


def patch_openai(
    ledger: TokenLedger | None = None,
    *,
    track_prompts: bool = False,
    user_id_extractor: Callable[[dict], str | None] | None = None,
    org_id_extractor: Callable[[dict], str | None] | None = None,
    tags_extractor: Callable[[dict], dict[str, Any]] | None = None,
) -> None:
    """
    Patch the OpenAI SDK to automatically track all API calls.
    
    Args:
        ledger: TokenLedger instance. If None, uses the singleton instance.
        track_prompts: If True, store a hash of the prompt for deduplication analysis.
        user_id_extractor: Function to extract user_id from request kwargs.
        org_id_extractor: Function to extract org_id from request kwargs.
        tags_extractor: Function to extract custom tags from request kwargs.
    
    Usage:
        from tokenledger import TokenLedger, patch_openai
        
        ledger = TokenLedger(database_url="postgresql://...")
        patch_openai(ledger)
        
        # Now all OpenAI calls are automatically tracked
        from openai import OpenAI
        client = OpenAI()
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello!"}]
        )
    """
    global _patched, _original_create, _original_acreate
    
    if _patched:
        logger.warning("OpenAI SDK already patched")
        return
    
    try:
        from openai.resources.chat import completions as chat_completions
    except ImportError:
        raise ImportError(
            "openai package not installed. Install with: pip install tokenledger[openai]"
        )
    
    from tokenledger.client import TokenLedger as TL
    
    if ledger is None:
        ledger = TL.get_instance()
        if ledger is None:
            raise ValueError(
                "No TokenLedger instance provided and no singleton instance exists. "
                "Create a TokenLedger instance first."
            )
    
    # Store originals
    _original_create = chat_completions.Completions.create
    _original_acreate = chat_completions.AsyncCompletions.create
    
    def _extract_usage_info(
        kwargs: dict[str, Any],
        response: Any,
        duration_ms: int,
        error: Exception | None = None,
    ) -> UsageRecord:
        """Extract usage information from request/response."""
        model = kwargs.get("model", "unknown")
        
        # Extract user/org/tags
        user_id = user_id_extractor(kwargs) if user_id_extractor else kwargs.get("user")
        org_id = org_id_extractor(kwargs) if org_id_extractor else None
        tags = tags_extractor(kwargs) if tags_extractor else {}
        
        # Add metadata tags
        if kwargs.get("stream"):
            tags["stream"] = True
        if kwargs.get("tools"):
            tags["has_tools"] = True
        if kwargs.get("response_format"):
            tags["response_format"] = str(kwargs["response_format"])
        
        # Handle error case
        if error:
            return UsageRecord(
                provider="openai",
                model=model,
                prompt_tokens=0,
                completion_tokens=0,
                duration_ms=duration_ms,
                user_id=user_id,
                org_id=org_id,
                tags=tags,
                endpoint="chat.completions",
                temperature=kwargs.get("temperature"),
                max_tokens=kwargs.get("max_tokens"),
                stream=kwargs.get("stream", False),
                status=Status.ERROR,
                error_type=type(error).__name__,
                error_message=str(error)[:500],
                prompt_hash=hash_prompt(kwargs.get("messages", [])) if track_prompts else None,
            )
        
        # Extract token usage from response
        usage = getattr(response, "usage", None)
        prompt_tokens = getattr(usage, "prompt_tokens", 0) if usage else 0
        completion_tokens = getattr(usage, "completion_tokens", 0) if usage else 0
        
        # Handle streaming responses (may not have usage)
        if kwargs.get("stream") and usage is None:
            # For streaming, we can't get accurate token counts without stream_options
            # If the user enabled stream_options.include_usage, it will be in the last chunk
            prompt_tokens = 0
            completion_tokens = 0
        
        # Get actual model used (may differ from requested)
        actual_model = getattr(response, "model", model)
        
        return UsageRecord(
            provider="openai",
            model=actual_model,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            duration_ms=duration_ms,
            user_id=user_id,
            org_id=org_id,
            tags=tags,
            endpoint="chat.completions",
            temperature=kwargs.get("temperature"),
            max_tokens=kwargs.get("max_tokens"),
            stream=kwargs.get("stream", False),
            status=Status.SUCCESS,
            prompt_hash=hash_prompt(kwargs.get("messages", [])) if track_prompts else None,
            cache_hit=getattr(usage, "prompt_tokens_details", {}).get("cached_tokens", 0) > 0 if usage else False,
        )
    
    @functools.wraps(_original_create)
    def patched_create(self: Any, *args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        error = None
        response = None
        
        try:
            response = _original_create(self, *args, **kwargs)
            return response
        except Exception as e:
            error = e
            raise
        finally:
            duration_ms = int((time.time() - start_time) * 1000)
            try:
                record = _extract_usage_info(kwargs, response, duration_ms, error)
                ledger.log(record)
            except Exception as log_error:
                logger.warning(f"Failed to log OpenAI usage: {log_error}")
    
    @functools.wraps(_original_acreate)
    async def patched_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        error = None
        response = None
        
        try:
            response = await _original_acreate(self, *args, **kwargs)
            return response
        except Exception as e:
            error = e
            raise
        finally:
            duration_ms = int((time.time() - start_time) * 1000)
            try:
                record = _extract_usage_info(kwargs, response, duration_ms, error)
                ledger.log(record)
            except Exception as log_error:
                logger.warning(f"Failed to log OpenAI usage: {log_error}")
    
    # Apply patches
    chat_completions.Completions.create = patched_create
    chat_completions.AsyncCompletions.create = patched_acreate
    
    _patched = True
    logger.info("OpenAI SDK patched for usage tracking")


def unpatch_openai() -> None:
    """Remove the OpenAI SDK patch."""
    global _patched, _original_create, _original_acreate
    
    if not _patched:
        return
    
    try:
        from openai.resources.chat import completions as chat_completions
    except ImportError:
        return
    
    if _original_create:
        chat_completions.Completions.create = _original_create
    if _original_acreate:
        chat_completions.AsyncCompletions.create = _original_acreate
    
    _patched = False
    _original_create = None
    _original_acreate = None
    logger.info("OpenAI SDK patch removed")
