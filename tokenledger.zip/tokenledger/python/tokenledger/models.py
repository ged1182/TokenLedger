"""Data models for TokenLedger."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from enum import Enum
import hashlib
import json


class Provider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    COHERE = "cohere"
    GOOGLE = "google"
    MISTRAL = "mistral"
    CUSTOM = "custom"


class Status(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"


# Model pricing per 1K tokens (USD) - Jan 2025
MODEL_PRICING: dict[str, dict[str, tuple[float, float]]] = {
    "openai": {
        "gpt-4o": (0.0025, 0.01),
        "gpt-4o-mini": (0.00015, 0.0006),
        "gpt-4o-2024-11-20": (0.0025, 0.01),
        "gpt-4o-2024-08-06": (0.0025, 0.01),
        "gpt-4-turbo": (0.01, 0.03),
        "gpt-4-turbo-preview": (0.01, 0.03),
        "gpt-4": (0.03, 0.06),
        "gpt-4-32k": (0.06, 0.12),
        "gpt-3.5-turbo": (0.0005, 0.0015),
        "gpt-3.5-turbo-0125": (0.0005, 0.0015),
        "o1": (0.015, 0.06),
        "o1-preview": (0.015, 0.06),
        "o1-mini": (0.003, 0.012),
        "o3-mini": (0.0011, 0.0044),
        "text-embedding-3-small": (0.00002, 0.0),
        "text-embedding-3-large": (0.00013, 0.0),
        "text-embedding-ada-002": (0.0001, 0.0),
    },
    "anthropic": {
        "claude-3-5-sonnet-20241022": (0.003, 0.015),
        "claude-3-5-sonnet-latest": (0.003, 0.015),
        "claude-3-5-haiku-20241022": (0.0008, 0.004),
        "claude-3-5-haiku-latest": (0.0008, 0.004),
        "claude-3-opus-20240229": (0.015, 0.075),
        "claude-3-opus-latest": (0.015, 0.075),
        "claude-3-sonnet-20240229": (0.003, 0.015),
        "claude-3-haiku-20240307": (0.00025, 0.00125),
        "claude-sonnet-4-20250514": (0.003, 0.015),
        "claude-opus-4-5-20251101": (0.015, 0.075),
    },
    "google": {
        "gemini-1.5-pro": (0.00125, 0.005),
        "gemini-1.5-flash": (0.000075, 0.0003),
        "gemini-2.0-flash": (0.0001, 0.0004),
    },
    "mistral": {
        "mistral-large": (0.002, 0.006),
        "mistral-small": (0.0002, 0.0006),
        "codestral": (0.0002, 0.0006),
    },
}


def get_model_pricing(provider: str, model: str) -> tuple[float, float]:
    """Get pricing for a model. Returns (prompt_cost_per_1k, completion_cost_per_1k)."""
    provider_pricing = MODEL_PRICING.get(provider.lower(), {})
    
    # Try exact match first
    if model in provider_pricing:
        return provider_pricing[model]
    
    # Try prefix match (for versioned models)
    for model_name, pricing in provider_pricing.items():
        if model.startswith(model_name) or model_name.startswith(model):
            return pricing
    
    # Default: return zeros (unknown model)
    return (0.0, 0.0)


def hash_prompt(prompt: str | list[dict[str, Any]]) -> str:
    """Create a SHA256 hash of the prompt for deduplication analysis."""
    if isinstance(prompt, list):
        prompt = json.dumps(prompt, sort_keys=True)
    return hashlib.sha256(prompt.encode()).hexdigest()


@dataclass
class UsageRecord:
    """A single LLM API call record."""
    
    provider: str
    model: str
    prompt_tokens: int
    completion_tokens: int
    
    # Optional identifiers
    request_id: str | None = None
    user_id: str | None = None
    org_id: str | None = None
    environment: str = "production"
    endpoint: str | None = None
    
    # Timing
    created_at: datetime = field(default_factory=datetime.utcnow)
    duration_ms: int | None = None
    
    # Cost (auto-calculated if not provided)
    prompt_cost_cents: float | None = None
    completion_cost_cents: float | None = None
    
    # Request details
    temperature: float | None = None
    max_tokens: int | None = None
    stream: bool = False
    
    # Custom metadata
    tags: dict[str, Any] = field(default_factory=dict)
    
    # Status
    status: Status = Status.SUCCESS
    error_type: str | None = None
    error_message: str | None = None
    
    # Optional prompt tracking
    prompt_hash: str | None = None
    cache_hit: bool = False
    
    def __post_init__(self) -> None:
        """Calculate costs if not provided."""
        if self.prompt_cost_cents is None or self.completion_cost_cents is None:
            prompt_per_1k, completion_per_1k = get_model_pricing(self.provider, self.model)
            
            if self.prompt_cost_cents is None:
                # Convert to cents
                self.prompt_cost_cents = (self.prompt_tokens / 1000.0) * prompt_per_1k * 100
            
            if self.completion_cost_cents is None:
                self.completion_cost_cents = (self.completion_tokens / 1000.0) * completion_per_1k * 100
    
    @property
    def total_tokens(self) -> int:
        """Total tokens used."""
        return self.prompt_tokens + self.completion_tokens
    
    @property
    def total_cost_cents(self) -> float:
        """Total cost in cents."""
        return (self.prompt_cost_cents or 0) + (self.completion_cost_cents or 0)
    
    @property
    def total_cost_usd(self) -> float:
        """Total cost in USD."""
        return self.total_cost_cents / 100.0
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for database insertion."""
        return {
            "provider": self.provider,
            "model": self.model,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "request_id": self.request_id,
            "user_id": self.user_id,
            "org_id": self.org_id,
            "environment": self.environment,
            "endpoint": self.endpoint,
            "created_at": self.created_at,
            "duration_ms": self.duration_ms,
            "prompt_cost_cents": self.prompt_cost_cents,
            "completion_cost_cents": self.completion_cost_cents,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "stream": self.stream,
            "tags": json.dumps(self.tags) if self.tags else "{}",
            "status": self.status.value,
            "error_type": self.error_type,
            "error_message": self.error_message,
            "prompt_hash": self.prompt_hash,
            "cache_hit": self.cache_hit,
        }


@dataclass
class CostSummary:
    """Aggregated cost summary."""
    
    total_requests: int
    total_tokens: int
    total_prompt_tokens: int
    total_completion_tokens: int
    total_cost_cents: float
    avg_latency_ms: float | None
    
    period_start: datetime
    period_end: datetime
    
    # Breakdown
    by_model: dict[str, float] = field(default_factory=dict)
    by_user: dict[str, float] = field(default_factory=dict)
    by_day: dict[str, float] = field(default_factory=dict)
    
    @property
    def total_cost_usd(self) -> float:
        return self.total_cost_cents / 100.0
