"""TokenLedger client for logging LLM usage to Postgres."""

from __future__ import annotations

import os
import logging
import threading
import queue
import atexit
from datetime import datetime, timedelta
from typing import Any, Callable
from contextlib import contextmanager
import time

import psycopg
from psycopg.rows import dict_row

from tokenledger.models import UsageRecord, CostSummary, Status

logger = logging.getLogger("tokenledger")


class TokenLedger:
    """
    TokenLedger client for logging LLM API usage to Postgres.
    
    Usage:
        ledger = TokenLedger(database_url="postgresql://...")
        
        # Manual logging
        ledger.log(UsageRecord(
            provider="openai",
            model="gpt-4o",
            prompt_tokens=100,
            completion_tokens=50,
            user_id="user_123"
        ))
        
        # Or use interceptors (recommended)
        from tokenledger import patch_openai
        patch_openai(ledger)
        
        # Now all OpenAI calls are automatically logged
        client = OpenAI()
        response = client.chat.completions.create(...)
    """
    
    _instance: TokenLedger | None = None
    _lock = threading.Lock()
    
    def __init__(
        self,
        database_url: str | None = None,
        *,
        async_logging: bool = True,
        batch_size: int = 100,
        flush_interval: float = 5.0,
        default_environment: str = "production",
        default_user_id: str | None = None,
        default_org_id: str | None = None,
        default_tags: dict[str, Any] | None = None,
        on_error: Callable[[Exception, UsageRecord], None] | None = None,
    ):
        """
        Initialize TokenLedger.
        
        Args:
            database_url: Postgres connection string. Defaults to DATABASE_URL env var.
            async_logging: If True, log records asynchronously in batches.
            batch_size: Number of records to batch before flushing.
            flush_interval: Seconds between automatic flushes.
            default_environment: Default environment tag for records.
            default_user_id: Default user ID for records.
            default_org_id: Default organization ID for records.
            default_tags: Default tags to add to all records.
            on_error: Callback for logging errors.
        """
        self.database_url = database_url or os.environ.get("DATABASE_URL")
        if not self.database_url:
            raise ValueError(
                "database_url is required. Pass it directly or set DATABASE_URL env var."
            )
        
        self.async_logging = async_logging
        self.batch_size = batch_size
        self.flush_interval = flush_interval
        self.default_environment = default_environment
        self.default_user_id = default_user_id
        self.default_org_id = default_org_id
        self.default_tags = default_tags or {}
        self.on_error = on_error
        
        # Connection pool
        self._pool: psycopg.ConnectionPool | None = None
        
        # Async logging queue
        self._queue: queue.Queue[UsageRecord | None] = queue.Queue()
        self._worker_thread: threading.Thread | None = None
        self._shutdown = threading.Event()
        
        if self.async_logging:
            self._start_worker()
            atexit.register(self.shutdown)
        
        # Set as singleton
        TokenLedger._instance = self
    
    @classmethod
    def get_instance(cls) -> TokenLedger | None:
        """Get the singleton instance."""
        return cls._instance
    
    def _get_pool(self) -> psycopg.ConnectionPool:
        """Get or create the connection pool."""
        if self._pool is None:
            with self._lock:
                if self._pool is None:
                    self._pool = psycopg.ConnectionPool(
                        self.database_url,
                        min_size=1,
                        max_size=10,
                        kwargs={"row_factory": dict_row}
                    )
        return self._pool
    
    def _start_worker(self) -> None:
        """Start the async logging worker thread."""
        self._worker_thread = threading.Thread(
            target=self._worker_loop,
            daemon=True,
            name="tokenledger-worker"
        )
        self._worker_thread.start()
    
    def _worker_loop(self) -> None:
        """Background worker that flushes records in batches."""
        batch: list[UsageRecord] = []
        last_flush = time.time()
        
        while not self._shutdown.is_set():
            try:
                # Get records with timeout for periodic flushing
                try:
                    record = self._queue.get(timeout=0.5)
                    if record is None:  # Shutdown signal
                        break
                    batch.append(record)
                except queue.Empty:
                    pass
                
                # Flush if batch is full or interval elapsed
                should_flush = (
                    len(batch) >= self.batch_size or
                    (batch and time.time() - last_flush >= self.flush_interval)
                )
                
                if should_flush:
                    self._flush_batch(batch)
                    batch = []
                    last_flush = time.time()
                    
            except Exception as e:
                logger.exception(f"Error in TokenLedger worker: {e}")
        
        # Final flush on shutdown
        if batch:
            self._flush_batch(batch)
    
    def _flush_batch(self, batch: list[UsageRecord]) -> None:
        """Flush a batch of records to the database."""
        if not batch:
            return
        
        try:
            pool = self._get_pool()
            with pool.connection() as conn:
                with conn.cursor() as cur:
                    # Use COPY for efficient bulk insert
                    columns = [
                        "provider", "model", "prompt_tokens", "completion_tokens",
                        "request_id", "user_id", "org_id", "environment", "endpoint",
                        "created_at", "duration_ms", "prompt_cost_cents", "completion_cost_cents",
                        "temperature", "max_tokens", "stream", "tags", "status",
                        "error_type", "error_message", "prompt_hash", "cache_hit"
                    ]
                    
                    placeholders = ", ".join(["%s"] * len(columns))
                    query = f"""
                        INSERT INTO llm_usage ({", ".join(columns)})
                        VALUES ({placeholders})
                    """
                    
                    for record in batch:
                        # Apply defaults
                        if record.environment == "production" and self.default_environment:
                            record.environment = self.default_environment
                        if record.user_id is None and self.default_user_id:
                            record.user_id = self.default_user_id
                        if record.org_id is None and self.default_org_id:
                            record.org_id = self.default_org_id
                        if self.default_tags:
                            record.tags = {**self.default_tags, **record.tags}
                        
                        data = record.to_dict()
                        values = [data[col] for col in columns]
                        
                        try:
                            cur.execute(query, values)
                        except Exception as e:
                            logger.error(f"Failed to insert record: {e}")
                            if self.on_error:
                                self.on_error(e, record)
                    
                    conn.commit()
                    
            logger.debug(f"Flushed {len(batch)} records to database")
            
        except Exception as e:
            logger.exception(f"Failed to flush batch: {e}")
            for record in batch:
                if self.on_error:
                    self.on_error(e, record)
    
    def log(self, record: UsageRecord) -> None:
        """
        Log a usage record.
        
        If async_logging is enabled, the record is queued for batch insert.
        Otherwise, it's inserted immediately.
        """
        if self.async_logging:
            self._queue.put(record)
        else:
            self._flush_batch([record])
    
    def log_sync(self, record: UsageRecord) -> None:
        """Log a record synchronously (bypass queue)."""
        self._flush_batch([record])
    
    def flush(self) -> None:
        """Force flush any pending records."""
        if not self.async_logging:
            return
        
        records = []
        while True:
            try:
                record = self._queue.get_nowait()
                if record is not None:
                    records.append(record)
            except queue.Empty:
                break
        
        if records:
            self._flush_batch(records)
    
    def shutdown(self) -> None:
        """Shutdown the client, flushing pending records."""
        if self._worker_thread and self._worker_thread.is_alive():
            self._shutdown.set()
            self._queue.put(None)  # Signal shutdown
            self._worker_thread.join(timeout=10)
        
        self.flush()
        
        if self._pool:
            self._pool.close()
    
    @contextmanager
    def track(
        self,
        provider: str,
        model: str,
        *,
        user_id: str | None = None,
        org_id: str | None = None,
        request_id: str | None = None,
        tags: dict[str, Any] | None = None,
    ):
        """
        Context manager for tracking an LLM call.
        
        Usage:
            with ledger.track("openai", "gpt-4o", user_id="user_123") as tracker:
                response = client.chat.completions.create(...)
                tracker.record(
                    prompt_tokens=response.usage.prompt_tokens,
                    completion_tokens=response.usage.completion_tokens
                )
        """
        start_time = time.time()
        tracker = UsageTracker(
            ledger=self,
            provider=provider,
            model=model,
            user_id=user_id,
            org_id=org_id,
            request_id=request_id,
            tags=tags or {},
            start_time=start_time,
        )
        
        try:
            yield tracker
        except Exception as e:
            tracker.error(type(e).__name__, str(e))
            raise
        finally:
            if tracker._recorded:
                self.log(tracker._build_record())
    
    # Query methods
    
    def get_cost_summary(
        self,
        *,
        start: datetime | None = None,
        end: datetime | None = None,
        user_id: str | None = None,
        org_id: str | None = None,
        model: str | None = None,
        environment: str | None = None,
    ) -> CostSummary:
        """Get aggregated cost summary for a time period."""
        if start is None:
            start = datetime.utcnow() - timedelta(days=30)
        if end is None:
            end = datetime.utcnow()
        
        pool = self._get_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                # Build query with filters
                conditions = ["created_at >= %s", "created_at <= %s"]
                params: list[Any] = [start, end]
                
                if user_id:
                    conditions.append("user_id = %s")
                    params.append(user_id)
                if org_id:
                    conditions.append("org_id = %s")
                    params.append(org_id)
                if model:
                    conditions.append("model = %s")
                    params.append(model)
                if environment:
                    conditions.append("environment = %s")
                    params.append(environment)
                
                where_clause = " AND ".join(conditions)
                
                # Main aggregates
                cur.execute(f"""
                    SELECT 
                        COUNT(*) as total_requests,
                        COALESCE(SUM(prompt_tokens + completion_tokens), 0) as total_tokens,
                        COALESCE(SUM(prompt_tokens), 0) as total_prompt_tokens,
                        COALESCE(SUM(completion_tokens), 0) as total_completion_tokens,
                        COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) as total_cost_cents,
                        AVG(duration_ms) as avg_latency_ms
                    FROM llm_usage
                    WHERE {where_clause}
                """, params)
                
                row = cur.fetchone()
                
                # By model breakdown
                cur.execute(f"""
                    SELECT model, SUM(prompt_cost_cents + completion_cost_cents) as cost
                    FROM llm_usage
                    WHERE {where_clause}
                    GROUP BY model
                    ORDER BY cost DESC
                """, params)
                by_model = {r["model"]: float(r["cost"]) for r in cur.fetchall()}
                
                # By user breakdown
                cur.execute(f"""
                    SELECT user_id, SUM(prompt_cost_cents + completion_cost_cents) as cost
                    FROM llm_usage
                    WHERE {where_clause} AND user_id IS NOT NULL
                    GROUP BY user_id
                    ORDER BY cost DESC
                    LIMIT 100
                """, params)
                by_user = {r["user_id"]: float(r["cost"]) for r in cur.fetchall()}
                
                # By day breakdown
                cur.execute(f"""
                    SELECT DATE(created_at) as day, SUM(prompt_cost_cents + completion_cost_cents) as cost
                    FROM llm_usage
                    WHERE {where_clause}
                    GROUP BY DATE(created_at)
                    ORDER BY day DESC
                """, params)
                by_day = {str(r["day"]): float(r["cost"]) for r in cur.fetchall()}
                
                return CostSummary(
                    total_requests=row["total_requests"],
                    total_tokens=row["total_tokens"],
                    total_prompt_tokens=row["total_prompt_tokens"],
                    total_completion_tokens=row["total_completion_tokens"],
                    total_cost_cents=float(row["total_cost_cents"]),
                    avg_latency_ms=float(row["avg_latency_ms"]) if row["avg_latency_ms"] else None,
                    period_start=start,
                    period_end=end,
                    by_model=by_model,
                    by_user=by_user,
                    by_day=by_day,
                )
    
    def get_top_users(
        self,
        *,
        start: datetime | None = None,
        end: datetime | None = None,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        """Get top users by cost."""
        if start is None:
            start = datetime.utcnow() - timedelta(days=30)
        if end is None:
            end = datetime.utcnow()
        
        pool = self._get_pool()
        with pool.connection() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT 
                        user_id,
                        COUNT(*) as request_count,
                        SUM(prompt_tokens + completion_tokens) as total_tokens,
                        SUM(prompt_cost_cents + completion_cost_cents) as total_cost_cents
                    FROM llm_usage
                    WHERE created_at >= %s AND created_at <= %s AND user_id IS NOT NULL
                    GROUP BY user_id
                    ORDER BY total_cost_cents DESC
                    LIMIT %s
                """, [start, end, limit])
                
                return [dict(row) for row in cur.fetchall()]


class UsageTracker:
    """Helper class for the track() context manager."""
    
    def __init__(
        self,
        ledger: TokenLedger,
        provider: str,
        model: str,
        user_id: str | None,
        org_id: str | None,
        request_id: str | None,
        tags: dict[str, Any],
        start_time: float,
    ):
        self._ledger = ledger
        self._provider = provider
        self._model = model
        self._user_id = user_id
        self._org_id = org_id
        self._request_id = request_id
        self._tags = tags
        self._start_time = start_time
        
        self._prompt_tokens = 0
        self._completion_tokens = 0
        self._status = Status.SUCCESS
        self._error_type: str | None = None
        self._error_message: str | None = None
        self._recorded = False
        self._extra: dict[str, Any] = {}
    
    def record(
        self,
        prompt_tokens: int,
        completion_tokens: int,
        **kwargs: Any,
    ) -> None:
        """Record token usage."""
        self._prompt_tokens = prompt_tokens
        self._completion_tokens = completion_tokens
        self._extra = kwargs
        self._recorded = True
    
    def error(self, error_type: str, message: str) -> None:
        """Record an error."""
        self._status = Status.ERROR
        self._error_type = error_type
        self._error_message = message
        self._recorded = True
    
    def _build_record(self) -> UsageRecord:
        """Build the usage record."""
        duration_ms = int((time.time() - self._start_time) * 1000)
        
        return UsageRecord(
            provider=self._provider,
            model=self._model,
            prompt_tokens=self._prompt_tokens,
            completion_tokens=self._completion_tokens,
            user_id=self._user_id,
            org_id=self._org_id,
            request_id=self._request_id,
            tags=self._tags,
            duration_ms=duration_ms,
            status=self._status,
            error_type=self._error_type,
            error_message=self._error_message,
            **self._extra,
        )
