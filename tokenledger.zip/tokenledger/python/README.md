# TokenLedger Python SDK

Track LLM API costs in your Postgres database.

## Installation

```bash
# Basic installation
pip install tokenledger

# With OpenAI support
pip install tokenledger[openai]

# With Anthropic support
pip install tokenledger[anthropic]

# With all providers
pip install tokenledger[all]
```

## Quick Start

```python
from tokenledger import TokenLedger, patch_openai
from openai import OpenAI

# Initialize
ledger = TokenLedger(database_url="postgresql://...")

# Patch OpenAI SDK
patch_openai(ledger)

# Use OpenAI normally - costs are tracked automatically
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
    user="user_123"  # Optional: track per user
)
```

## Configuration

```python
ledger = TokenLedger(
    database_url="postgresql://...",  # Required
    async_logging=True,               # Log asynchronously (default: True)
    batch_size=100,                   # Batch size for async logging
    flush_interval=5.0,               # Seconds between flushes
    default_environment="production", # Default environment tag
    default_user_id=None,             # Default user ID for all requests
    default_org_id=None,              # Default org ID for all requests
    default_tags={},                  # Default tags for all requests
)
```

## Supported Providers

### OpenAI

```python
from tokenledger import patch_openai

patch_openai(
    ledger,
    track_prompts=False,  # Hash prompts for deduplication analysis
    user_id_extractor=lambda kwargs: kwargs.get("user"),
    tags_extractor=lambda kwargs: {"feature": "chat"},
)
```

### Anthropic

```python
from tokenledger import patch_anthropic

patch_anthropic(
    ledger,
    track_prompts=False,
    user_id_extractor=lambda kwargs: kwargs.get("metadata", {}).get("user_id"),
)
```

## Manual Logging

```python
from tokenledger import UsageRecord

ledger.log(UsageRecord(
    provider="custom",
    model="my-model",
    prompt_tokens=100,
    completion_tokens=50,
    user_id="user_123",
    tags={"feature": "summarization"},
))
```

## Context Manager

```python
with ledger.track("openai", "gpt-4o", user_id="user_123") as tracker:
    # Make your API call
    response = custom_api_call()
    
    # Record the usage
    tracker.record(
        prompt_tokens=response.usage.prompt_tokens,
        completion_tokens=response.usage.completion_tokens,
    )
```

## Querying Data

```python
from datetime import datetime, timedelta

# Get cost summary
summary = ledger.get_cost_summary(
    start=datetime.utcnow() - timedelta(days=7),
    user_id="user_123",
)

print(f"Total cost: ${summary.total_cost_usd:.2f}")
print(f"Requests: {summary.total_requests}")

# Get top users
top_users = ledger.get_top_users(limit=10)
for user in top_users:
    print(f"{user['user_id']}: ${user['total_cost_cents']/100:.2f}")
```

## License

MIT
