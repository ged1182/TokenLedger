import { useState, useEffect } from 'react';
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import {
  DollarSign, Zap, Clock, AlertTriangle, TrendingUp,
  TrendingDown, Users, Activity, RefreshCw
} from 'lucide-react';
import { format, parseISO, subDays } from 'date-fns';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:8000';

// Types
interface Summary {
  total_requests: number;
  total_tokens: number;
  total_cost_usd: number;
  avg_latency_ms: number | null;
  period_start: string;
  period_end: string;
}

interface DailyCost {
  date: string;
  cost_usd: number;
  requests: number;
  tokens: number;
}

interface ModelBreakdown {
  model: string;
  provider: string;
  requests: number;
  tokens: number;
  cost_usd: number;
  avg_latency_ms: number | null;
}

interface TopUser {
  user_id: string;
  requests: number;
  tokens: number;
  cost_usd: number;
}

interface RealtimeStats {
  requests_last_hour: number;
  cost_last_hour: number;
  avg_latency_ms: number;
  errors_last_hour: number;
  minutes: { minute: string; requests: number; cost: number }[];
}

// Colors
const COLORS = ['#6366f1', '#8b5cf6', '#a855f7', '#d946ef', '#ec4899', '#f43f5e', '#f97316', '#eab308'];
const CHART_COLORS = {
  primary: '#6366f1',
  secondary: '#8b5cf6',
  success: '#22c55e',
  warning: '#eab308',
  danger: '#ef4444',
};

// Utility components
function StatCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  trend,
  color = 'indigo'
}: {
  title: string;
  value: string;
  subtitle?: string;
  icon: any;
  trend?: { value: number; label: string };
  color?: string;
}) {
  const colorClasses: Record<string, string> = {
    indigo: 'bg-indigo-500',
    purple: 'bg-purple-500',
    green: 'bg-green-500',
    amber: 'bg-amber-500',
    red: 'bg-red-500',
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-500">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          {subtitle && <p className="text-sm text-gray-400 mt-1">{subtitle}</p>}
          {trend && (
            <div className="flex items-center mt-2">
              {trend.value >= 0 ? (
                <TrendingUp className="w-4 h-4 text-red-500 mr-1" />
              ) : (
                <TrendingDown className="w-4 h-4 text-green-500 mr-1" />
              )}
              <span className={trend.value >= 0 ? 'text-red-500' : 'text-green-500'}>
                {Math.abs(trend.value).toFixed(1)}%
              </span>
              <span className="text-gray-400 ml-1">{trend.label}</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${colorClasses[color]} bg-opacity-10`}>
          <Icon className={`w-6 h-6 text-${color}-500`} style={{ color: colorClasses[color].replace('bg-', '#').replace('-500', '') }} />
        </div>
      </div>
    </div>
  );
}

function formatCurrency(value: number): string {
  if (value >= 1000) {
    return `$${(value / 1000).toFixed(1)}k`;
  }
  return `$${value.toFixed(2)}`;
}

function formatNumber(value: number): string {
  if (value >= 1000000) {
    return `${(value / 1000000).toFixed(1)}M`;
  }
  if (value >= 1000) {
    return `${(value / 1000).toFixed(1)}k`;
  }
  return value.toString();
}

export default function App() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [dailyCosts, setDailyCosts] = useState<DailyCost[]>([]);
  const [models, setModels] = useState<ModelBreakdown[]>([]);
  const [topUsers, setTopUsers] = useState<TopUser[]>([]);
  const [realtime, setRealtime] = useState<RealtimeStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState(30);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  async function fetchData() {
    try {
      const start = subDays(new Date(), timeRange).toISOString();
      const end = new Date().toISOString();

      const [summaryRes, dailyRes, modelsRes, usersRes, realtimeRes] = await Promise.all([
        fetch(`${API_BASE}/api/summary?start=${start}&end=${end}`),
        fetch(`${API_BASE}/api/costs/daily?start=${start}&end=${end}`),
        fetch(`${API_BASE}/api/models?start=${start}&end=${end}`),
        fetch(`${API_BASE}/api/users/top?start=${start}&end=${end}&limit=5`),
        fetch(`${API_BASE}/api/stats/realtime`),
      ]);

      setSummary(await summaryRes.json());
      setDailyCosts(await dailyRes.json());
      setModels(await modelsRes.json());
      setTopUsers(await usersRes.json());
      setRealtime(await realtimeRes.json());
      setLastUpdated(new Date());
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000); // Refresh every 30s
    return () => clearInterval(interval);
  }, [timeRange]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin mx-auto" />
          <p className="mt-2 text-gray-500">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  const totalCost = summary?.total_cost_usd || 0;
  const modelPieData = models.map((m, i) => ({
    name: m.model.split('-').slice(-2).join('-'),
    value: m.cost_usd,
    fullName: m.model,
    color: COLORS[i % COLORS.length],
  }));

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">TokenLedger</h1>
                <p className="text-sm text-gray-500">LLM Cost Analytics</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(Number(e.target.value))}
                className="px-3 py-2 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value={7}>Last 7 days</option>
                <option value={14}>Last 14 days</option>
                <option value={30}>Last 30 days</option>
                <option value={90}>Last 90 days</option>
              </select>
              
              <button
                onClick={fetchData}
                className="flex items-center space-x-2 px-3 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition-colors text-sm"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Refresh</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Real-time banner */}
        {realtime && (
          <div className="mb-6 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-xl p-4 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5" />
                  <span className="font-medium">Last Hour</span>
                </div>
                <div className="flex items-center space-x-6 text-sm">
                  <span><strong>{realtime.requests_last_hour}</strong> requests</span>
                  <span><strong>{formatCurrency(realtime.cost_last_hour)}</strong> spent</span>
                  <span><strong>{realtime.avg_latency_ms.toFixed(0)}ms</strong> avg latency</span>
                  {realtime.errors_last_hour > 0 && (
                    <span className="text-red-200">
                      <AlertTriangle className="w-4 h-4 inline mr-1" />
                      {realtime.errors_last_hour} errors
                    </span>
                  )}
                </div>
              </div>
              <div className="w-32 h-8">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={realtime.minutes.slice(-30)}>
                    <Area
                      type="monotone"
                      dataKey="requests"
                      stroke="rgba(255,255,255,0.8)"
                      fill="rgba(255,255,255,0.2)"
                      strokeWidth={1.5}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Cost"
            value={formatCurrency(totalCost)}
            subtitle={`${timeRange} day period`}
            icon={DollarSign}
            color="indigo"
          />
          <StatCard
            title="Total Requests"
            value={formatNumber(summary?.total_requests || 0)}
            subtitle={`${((summary?.total_requests || 0) / timeRange).toFixed(0)}/day avg`}
            icon={Zap}
            color="purple"
          />
          <StatCard
            title="Total Tokens"
            value={formatNumber(summary?.total_tokens || 0)}
            subtitle="Prompt + Completion"
            icon={Activity}
            color="green"
          />
          <StatCard
            title="Avg Latency"
            value={summary?.avg_latency_ms ? `${summary.avg_latency_ms.toFixed(0)}ms` : 'N/A'}
            subtitle="Response time"
            icon={Clock}
            color="amber"
          />
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Daily Cost Trend */}
          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Daily Cost Trend</h2>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dailyCosts}>
                  <defs>
                    <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={CHART_COLORS.primary} stopOpacity={0.3} />
                      <stop offset="95%" stopColor={CHART_COLORS.primary} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis
                    dataKey="date"
                    tickFormatter={(value) => format(parseISO(value), 'MMM d')}
                    stroke="#9ca3af"
                    fontSize={12}
                  />
                  <YAxis
                    tickFormatter={(value) => `$${value}`}
                    stroke="#9ca3af"
                    fontSize={12}
                  />
                  <Tooltip
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'Cost']}
                    labelFormatter={(label) => format(parseISO(label), 'MMMM d, yyyy')}
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="cost_usd"
                    stroke={CHART_COLORS.primary}
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorCost)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Cost by Model Pie */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Cost by Model</h2>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={modelPieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {modelPieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: number) => [`$${value.toFixed(2)}`, 'Cost']}
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e5e7eb',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend
                    formatter={(value, entry: any) => (
                      <span className="text-xs text-gray-600">{value}</span>
                    )}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Bottom Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Model Breakdown Table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Model Breakdown</h2>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs text-gray-500 uppercase tracking-wider">
                    <th className="pb-3">Model</th>
                    <th className="pb-3 text-right">Requests</th>
                    <th className="pb-3 text-right">Tokens</th>
                    <th className="pb-3 text-right">Cost</th>
                    <th className="pb-3 text-right">Latency</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {models.slice(0, 6).map((model, i) => (
                    <tr key={model.model} className="hover:bg-gray-50">
                      <td className="py-3">
                        <div className="flex items-center space-x-2">
                          <div
                            className="w-2 h-2 rounded-full"
                            style={{ backgroundColor: COLORS[i % COLORS.length] }}
                          />
                          <span className="font-medium text-gray-900 text-sm">
                            {model.model.split('-').slice(-3).join('-')}
                          </span>
                        </div>
                        <span className="text-xs text-gray-400">{model.provider}</span>
                      </td>
                      <td className="py-3 text-right text-sm text-gray-600">
                        {formatNumber(model.requests)}
                      </td>
                      <td className="py-3 text-right text-sm text-gray-600">
                        {formatNumber(model.tokens)}
                      </td>
                      <td className="py-3 text-right text-sm font-medium text-gray-900">
                        {formatCurrency(model.cost_usd)}
                      </td>
                      <td className="py-3 text-right text-sm text-gray-600">
                        {model.avg_latency_ms ? `${model.avg_latency_ms.toFixed(0)}ms` : '-'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Users */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Top Users by Cost</h2>
            {topUsers.length > 0 ? (
              <div className="space-y-4">
                {topUsers.map((user, i) => {
                  const percentage = (user.cost_usd / totalCost) * 100;
                  return (
                    <div key={user.user_id}>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center space-x-2">
                          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-purple-500 flex items-center justify-center text-white text-xs font-medium">
                            {user.user_id.slice(0, 2).toUpperCase()}
                          </div>
                          <span className="text-sm font-medium text-gray-900">
                            {user.user_id.length > 20 ? `${user.user_id.slice(0, 20)}...` : user.user_id}
                          </span>
                        </div>
                        <span className="text-sm font-semibold text-gray-900">
                          {formatCurrency(user.cost_usd)}
                        </span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{
                              width: `${percentage}%`,
                              backgroundColor: COLORS[i % COLORS.length],
                            }}
                          />
                        </div>
                        <span className="text-xs text-gray-500 w-12 text-right">
                          {percentage.toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex items-center space-x-4 mt-1 text-xs text-gray-400">
                        <span>{formatNumber(user.requests)} requests</span>
                        <span>{formatNumber(user.tokens)} tokens</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                <Users className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No user data available</p>
                <p className="text-xs mt-1">Pass user_id when logging to see breakdown</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center text-sm text-gray-400">
          Last updated: {format(lastUpdated, 'HH:mm:ss')} · 
          Auto-refreshes every 30 seconds
        </div>
      </main>
    </div>
  );
}
