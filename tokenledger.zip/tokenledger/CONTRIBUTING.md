# Contributing to TokenLedger

Thank you for your interest in contributing to TokenLedger! 🎉

## Getting Started

### Prerequisites

- Python 3.9+
- Node.js 18+
- Docker (optional, for local development)
- PostgreSQL 14+

### Development Setup

1. **Fork and clone the repository**
   ```bash
   git clone https://github.com/YOUR_USERNAME/tokenledger.git
   cd tokenledger
   ```

2. **Set up the Python SDK**
   ```bash
   cd python
   python -m venv venv
   source venv/bin/activate  # or `venv\Scripts\activate` on Windows
   pip install -e ".[dev,all]"
   ```

3. **Set up the dashboard**
   ```bash
   cd ../dashboard
   npm install
   ```

4. **Start the database**
   ```bash
   cd ..
   docker compose up -d postgres
   ```

5. **Run the API**
   ```bash
   cd api
   uvicorn main:app --reload
   ```

6. **Run the dashboard**
   ```bash
   cd ../dashboard
   npm run dev
   ```

## Code Style

### Python
- We use `black` for formatting
- We use `ruff` for linting
- Run `black .` and `ruff check .` before committing

### TypeScript
- We use Prettier for formatting
- Run `npm run lint` before committing

## Testing

### Python SDK
```bash
cd python
pytest
```

### API
```bash
cd api
pytest
```

## Pull Request Process

1. Create a feature branch from `main`
2. Make your changes
3. Add tests for new functionality
4. Ensure all tests pass
5. Update documentation if needed
6. Submit a PR with a clear description

## Adding New Providers

To add support for a new LLM provider:

1. Create a new file in `python/tokenledger/interceptors/`
2. Implement the `patch_<provider>()` function
3. Add pricing data to `python/tokenledger/models.py`
4. Update the README
5. Add tests

Example structure:
```python
# python/tokenledger/interceptors/newprovider.py

def patch_newprovider(ledger: TokenLedger | None = None, **kwargs):
    # Implementation
    pass
```

## Reporting Issues

- Use the GitHub issue tracker
- Include reproduction steps
- Include Python/Node versions
- Include relevant logs

## Questions?

- Open a GitHub Discussion
- Join our Discord

Thank you for contributing! 🙏
