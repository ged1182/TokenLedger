# TokenLedger ⚡

**Know exactly what your AI features cost. Per user. Per endpoint. Per day.**

<p align="center">
  <img src="docs/screenshot.png" alt="TokenLedger Dashboard" width="100%">
</p>

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-blue.svg)](https://www.typescriptlang.org/)

---

## The Problem

You're building AI features. Your OpenAI/Anthropic bill is growing. Your CFO asks "how much are we spending on AI?" and you have no idea.

- Which users are costing you the most?
- Which endpoints are burning tokens?
- Is that new feature worth the LLM cost?

**TokenLedger answers these questions.**

## Features

- 🔌 **Drop-in SDK** - One line to instrument OpenAI/Anthropic
- 🗄️ **Postgres-native** - Your data stays in your database (works with Supabase!)
- 📊 **Beautiful dashboard** - Screenshot-worthy cost analytics
- 👥 **Per-user tracking** - Know who's costing what
- ⚡ **Real-time** - See costs as they happen
- 🚨 **Alerts** - Get notified before budgets blow up
- 🔒 **Self-hosted** - No data leaves your infrastructure

## Quick Start

### 1. Install the SDK

```bash
pip install tokenledger
```

### 2. Set up the database

```bash
# Using Docker
docker compose up -d postgres

# Or use your existing Postgres/Supabase
psql $DATABASE_URL < migrations/001_initial.sql
```

### 3. Instrument your code

```python
from tokenledger import TokenLedger, patch_openai
from openai import OpenAI

# Initialize TokenLedger
ledger = TokenLedger(database_url="postgresql://...")

# Patch OpenAI - that's it!
patch_openai(ledger)

# Your existing code works unchanged
client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello!"}],
    user="user_123"  # Optional: track per user
)

# Every call is now logged with:
# - Token counts (prompt + completion)
# - Cost (auto-calculated)
# - Latency
# - User ID
# - Model used
```

### 4. View your dashboard

```bash
docker compose up -d
open http://localhost:3000
```

## Installation Options

### Option A: Docker (Recommended)

```bash
git clone https://github.com/tokenledger/tokenledger.git
cd tokenledger
cp .env.example .env
docker compose up -d
```

### Option B: Supabase

Perfect for startups already using Supabase:

1. Run the migration in Supabase SQL editor:
   ```sql
   -- Copy contents of migrations/001_initial.sql
   ```

2. Use your Supabase connection string:
   ```python
   ledger = TokenLedger(
       database_url="postgresql://postgres:[password]@db.[ref].supabase.co:5432/postgres"
   )
   ```

### Option C: Existing Postgres

```bash
pip install tokenledger
psql $DATABASE_URL < migrations/001_initial.sql
```

## SDK Usage

### Basic Usage

```python
from tokenledger import TokenLedger, patch_openai, patch_anthropic

ledger = TokenLedger(
    database_url="postgresql://...",
    default_environment="production",
    default_org_id="org_123",
)

# Patch providers
patch_openai(ledger)
patch_anthropic(ledger)

# All calls are now tracked automatically!
```

### With User Tracking

```python
# OpenAI supports user parameter natively
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[...],
    user="user_123"  # This gets logged
)

# For Anthropic, use metadata
response = client.messages.create(
    model="claude-3-5-sonnet-20241022",
    messages=[...],
    metadata={"user_id": "user_123"}
)
```

### Custom Tags

```python
patch_openai(
    ledger,
    tags_extractor=lambda kwargs: {
        "feature": "chat",
        "version": "v2",
        "experiment": kwargs.get("extra_body", {}).get("experiment_id")
    }
)
```

### Manual Logging

```python
from tokenledger import UsageRecord

ledger.log(UsageRecord(
    provider="openai",
    model="gpt-4o",
    prompt_tokens=150,
    completion_tokens=50,
    user_id="user_123",
    tags={"feature": "summarization"}
))
```

### Context Manager

```python
with ledger.track("openai", "gpt-4o", user_id="user_123") as tracker:
    response = some_custom_llm_call()
    tracker.record(
        prompt_tokens=response.prompt_tokens,
        completion_tokens=response.completion_tokens
    )
```

## API Reference

### Query Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/summary` | Aggregated cost summary |
| `GET /api/costs/daily` | Daily cost breakdown |
| `GET /api/costs/hourly` | Hourly cost breakdown (24h) |
| `GET /api/models` | Cost by model |
| `GET /api/users/top` | Top users by cost |
| `GET /api/errors` | Error summary |
| `GET /api/recent` | Recent requests |
| `GET /api/stats/realtime` | Real-time stats |

All endpoints support these filters:
- `start` / `end` - Time range (ISO 8601)
- `user_id` - Filter by user
- `org_id` - Filter by organization
- `model` - Filter by model

### Example Query

```bash
curl "http://localhost:8000/api/summary?start=2024-01-01T00:00:00Z&user_id=user_123"
```

## Supported Providers

| Provider | SDK | Status |
|----------|-----|--------|
| OpenAI | `openai>=1.0.0` | ✅ Full support |
| Anthropic | `anthropic>=0.18.0` | ✅ Full support |
| Google | Coming soon | 🚧 |
| Mistral | Coming soon | 🚧 |
| Cohere | Coming soon | 🚧 |

## Model Pricing

TokenLedger includes up-to-date pricing for all major models. Costs are calculated automatically. To update pricing:

```sql
INSERT INTO llm_model_pricing (provider, model, prompt_cost_per_1k, completion_cost_per_1k)
VALUES ('openai', 'gpt-5', 0.05, 0.15);
```

## Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `DATABASE_URL` | Postgres connection string | Required |
| `TOKENLEDGER_ENVIRONMENT` | Default environment tag | `production` |
| `TOKENLEDGER_BATCH_SIZE` | Records per batch | `100` |
| `TOKENLEDGER_FLUSH_INTERVAL` | Seconds between flushes | `5.0` |

### SDK Options

```python
ledger = TokenLedger(
    database_url="postgresql://...",
    async_logging=True,          # Log asynchronously (recommended)
    batch_size=100,              # Batch size for async logging
    flush_interval=5.0,          # Seconds between flushes
    default_environment="prod",  # Default environment tag
    default_user_id=None,        # Default user ID
    default_org_id=None,         # Default org ID
    default_tags={},             # Default tags for all records
    on_error=lambda e, r: ...,   # Error callback
)
```

## Performance

TokenLedger is designed for high-throughput production use:

- **Async logging** - API calls are not blocked
- **Batched inserts** - Efficient database writes
- **Connection pooling** - Minimal connection overhead
- **Indexed queries** - Fast dashboard queries

Benchmarks (M1 MacBook, local Postgres):
- Logging overhead: <1ms per call
- Dashboard queries: <50ms for 1M records

## Contributing

We love contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

```bash
# Development setup
git clone https://github.com/tokenledger/tokenledger.git
cd tokenledger

# Python SDK
cd python
pip install -e ".[dev]"
pytest

# Dashboard
cd ../dashboard
npm install
npm run dev
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Support

- 📖 [Documentation](https://tokenledger.dev/docs)
- 💬 [Discord](https://discord.gg/tokenledger)
- 🐛 [Issues](https://github.com/tokenledger/tokenledger/issues)
- 🐦 [Twitter](https://twitter.com/tokenledger)

---

<p align="center">
  Built with ❤️ by developers who got tired of surprise LLM bills
</p>
