# Quickstart Guide

Get TokenLedger running in 5 minutes.

## Option 1: Docker (Fastest)

```bash
# Clone the repo
git clone https://github.com/tokenledger/tokenledger.git
cd tokenledger

# Copy environment file
cp .env.example .env

# Start everything
docker compose up -d

# Open the dashboard
open http://localhost:3000
```

## Option 2: Supabase

Perfect if you're already using Supabase:

### 1. Run the migration

Go to your Supabase dashboard → SQL Editor → New Query

Paste the contents of `migrations/001_initial.sql` and run it.

### 2. Install the SDK

```bash
pip install tokenledger
```

### 3. Configure

```python
from tokenledger import TokenLedger, patch_openai

# Get your connection string from Supabase dashboard
# Settings → Database → Connection string → URI
ledger = TokenLedger(
    database_url="postgresql://postgres:[PASSWORD]@db.[REF].supabase.co:5432/postgres"
)

# Patch OpenAI
patch_openai(ledger)
```

### 4. Run the dashboard locally

```bash
cd dashboard
npm install
VITE_API_URL=http://localhost:8000 npm run dev
```

## Option 3: Manual Setup

### 1. Set up Postgres

```bash
# Create database
createdb tokenledger

# Run migration
psql tokenledger < migrations/001_initial.sql
```

### 2. Install and configure

```bash
pip install tokenledger
```

```python
import os
os.environ["DATABASE_URL"] = "postgresql://localhost/tokenledger"

from tokenledger import TokenLedger, patch_openai
ledger = TokenLedger()
patch_openai(ledger)
```

### 3. Run the API

```bash
cd api
pip install fastapi uvicorn psycopg[binary]
uvicorn main:app --host 0.0.0.0 --port 8000
```

### 4. Run the dashboard

```bash
cd dashboard
npm install
npm run dev
```

## Verify It's Working

```python
from openai import OpenAI

client = OpenAI()
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Say hello!"}],
    user="test_user"
)

print(response.choices[0].message.content)
```

Now check your dashboard at http://localhost:3000 - you should see the request!

## Next Steps

- [Configure alerts](./alerts.md)
- [Add custom tags](./custom-tags.md)
- [Deploy to production](./deployment.md)
