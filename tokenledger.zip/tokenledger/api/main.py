"""TokenLedger API - Dashboard backend."""

import os
from datetime import datetime, timedelta
from typing import Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Query, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import psycopg
from psycopg.rows import dict_row


# Configuration
DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:postgres@localhost:5432/tokenledger")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage database connection pool lifecycle."""
    app.state.pool = psycopg.ConnectionPool(
        DATABASE_URL,
        min_size=1,
        max_size=10,
        kwargs={"row_factory": dict_row}
    )
    yield
    app.state.pool.close()


app = FastAPI(
    title="TokenLedger API",
    description="LLM Cost Analytics API",
    version="0.1.0",
    lifespan=lifespan,
)

# CORS for dashboard
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_pool():
    return app.state.pool


# Pydantic models
class CostSummary(BaseModel):
    total_requests: int
    total_tokens: int
    total_cost_usd: float
    avg_latency_ms: float | None
    period_start: datetime
    period_end: datetime


class ModelBreakdown(BaseModel):
    model: str
    provider: str
    requests: int
    tokens: int
    cost_usd: float
    avg_latency_ms: float | None


class DailyCost(BaseModel):
    date: str
    cost_usd: float
    requests: int
    tokens: int


class TopUser(BaseModel):
    user_id: str
    requests: int
    tokens: int
    cost_usd: float


class HourlyCost(BaseModel):
    hour: str
    cost_usd: float
    requests: int


class ErrorSummary(BaseModel):
    error_type: str
    count: int
    last_seen: datetime


# API Routes

@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "version": "0.1.0"}


@app.get("/api/summary", response_model=CostSummary)
async def get_summary(
    start: datetime = Query(default=None, description="Start of period (default: 30 days ago)"),
    end: datetime = Query(default=None, description="End of period (default: now)"),
    user_id: str | None = Query(default=None),
    org_id: str | None = Query(default=None),
    model: str | None = Query(default=None),
    environment: str | None = Query(default=None),
    pool=Depends(get_pool),
):
    """Get cost summary for a time period."""
    if start is None:
        start = datetime.utcnow() - timedelta(days=30)
    if end is None:
        end = datetime.utcnow()
    
    conditions = ["created_at >= %s", "created_at <= %s"]
    params: list[Any] = [start, end]
    
    if user_id:
        conditions.append("user_id = %s")
        params.append(user_id)
    if org_id:
        conditions.append("org_id = %s")
        params.append(org_id)
    if model:
        conditions.append("model = %s")
        params.append(model)
    if environment:
        conditions.append("environment = %s")
        params.append(environment)
    
    where_clause = " AND ".join(conditions)
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(f"""
                SELECT 
                    COUNT(*)::int as total_requests,
                    COALESCE(SUM(prompt_tokens + completion_tokens), 0)::bigint as total_tokens,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as total_cost_usd,
                    AVG(duration_ms) as avg_latency_ms
                FROM llm_usage
                WHERE {where_clause}
            """, params)
            
            row = cur.fetchone()
            
            return CostSummary(
                total_requests=row["total_requests"],
                total_tokens=int(row["total_tokens"]),
                total_cost_usd=float(row["total_cost_usd"]),
                avg_latency_ms=float(row["avg_latency_ms"]) if row["avg_latency_ms"] else None,
                period_start=start,
                period_end=end,
            )


@app.get("/api/costs/daily", response_model=list[DailyCost])
async def get_daily_costs(
    start: datetime = Query(default=None),
    end: datetime = Query(default=None),
    user_id: str | None = Query(default=None),
    org_id: str | None = Query(default=None),
    model: str | None = Query(default=None),
    pool=Depends(get_pool),
):
    """Get daily cost breakdown."""
    if start is None:
        start = datetime.utcnow() - timedelta(days=30)
    if end is None:
        end = datetime.utcnow()
    
    conditions = ["created_at >= %s", "created_at <= %s"]
    params: list[Any] = [start, end]
    
    if user_id:
        conditions.append("user_id = %s")
        params.append(user_id)
    if org_id:
        conditions.append("org_id = %s")
        params.append(org_id)
    if model:
        conditions.append("model = %s")
        params.append(model)
    
    where_clause = " AND ".join(conditions)
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(f"""
                SELECT 
                    DATE(created_at) as date,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as cost_usd,
                    COUNT(*)::int as requests,
                    COALESCE(SUM(prompt_tokens + completion_tokens), 0)::bigint as tokens
                FROM llm_usage
                WHERE {where_clause}
                GROUP BY DATE(created_at)
                ORDER BY date ASC
            """, params)
            
            return [
                DailyCost(
                    date=str(row["date"]),
                    cost_usd=float(row["cost_usd"]),
                    requests=row["requests"],
                    tokens=int(row["tokens"]),
                )
                for row in cur.fetchall()
            ]


@app.get("/api/costs/hourly", response_model=list[HourlyCost])
async def get_hourly_costs(
    start: datetime = Query(default=None),
    end: datetime = Query(default=None),
    pool=Depends(get_pool),
):
    """Get hourly cost breakdown (last 24 hours by default)."""
    if start is None:
        start = datetime.utcnow() - timedelta(hours=24)
    if end is None:
        end = datetime.utcnow()
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 
                    DATE_TRUNC('hour', created_at) as hour,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as cost_usd,
                    COUNT(*)::int as requests
                FROM llm_usage
                WHERE created_at >= %s AND created_at <= %s
                GROUP BY DATE_TRUNC('hour', created_at)
                ORDER BY hour ASC
            """, [start, end])
            
            return [
                HourlyCost(
                    hour=row["hour"].isoformat(),
                    cost_usd=float(row["cost_usd"]),
                    requests=row["requests"],
                )
                for row in cur.fetchall()
            ]


@app.get("/api/models", response_model=list[ModelBreakdown])
async def get_model_breakdown(
    start: datetime = Query(default=None),
    end: datetime = Query(default=None),
    user_id: str | None = Query(default=None),
    org_id: str | None = Query(default=None),
    pool=Depends(get_pool),
):
    """Get cost breakdown by model."""
    if start is None:
        start = datetime.utcnow() - timedelta(days=30)
    if end is None:
        end = datetime.utcnow()
    
    conditions = ["created_at >= %s", "created_at <= %s"]
    params: list[Any] = [start, end]
    
    if user_id:
        conditions.append("user_id = %s")
        params.append(user_id)
    if org_id:
        conditions.append("org_id = %s")
        params.append(org_id)
    
    where_clause = " AND ".join(conditions)
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(f"""
                SELECT 
                    model,
                    provider,
                    COUNT(*)::int as requests,
                    COALESCE(SUM(prompt_tokens + completion_tokens), 0)::bigint as tokens,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as cost_usd,
                    AVG(duration_ms) as avg_latency_ms
                FROM llm_usage
                WHERE {where_clause}
                GROUP BY model, provider
                ORDER BY cost_usd DESC
            """, params)
            
            return [
                ModelBreakdown(
                    model=row["model"],
                    provider=row["provider"],
                    requests=row["requests"],
                    tokens=int(row["tokens"]),
                    cost_usd=float(row["cost_usd"]),
                    avg_latency_ms=float(row["avg_latency_ms"]) if row["avg_latency_ms"] else None,
                )
                for row in cur.fetchall()
            ]


@app.get("/api/users/top", response_model=list[TopUser])
async def get_top_users(
    start: datetime = Query(default=None),
    end: datetime = Query(default=None),
    limit: int = Query(default=10, ge=1, le=100),
    pool=Depends(get_pool),
):
    """Get top users by cost."""
    if start is None:
        start = datetime.utcnow() - timedelta(days=30)
    if end is None:
        end = datetime.utcnow()
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 
                    user_id,
                    COUNT(*)::int as requests,
                    COALESCE(SUM(prompt_tokens + completion_tokens), 0)::bigint as tokens,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as cost_usd
                FROM llm_usage
                WHERE created_at >= %s AND created_at <= %s AND user_id IS NOT NULL
                GROUP BY user_id
                ORDER BY cost_usd DESC
                LIMIT %s
            """, [start, end, limit])
            
            return [
                TopUser(
                    user_id=row["user_id"],
                    requests=row["requests"],
                    tokens=int(row["tokens"]),
                    cost_usd=float(row["cost_usd"]),
                )
                for row in cur.fetchall()
            ]


@app.get("/api/errors", response_model=list[ErrorSummary])
async def get_error_summary(
    start: datetime = Query(default=None),
    end: datetime = Query(default=None),
    pool=Depends(get_pool),
):
    """Get error summary."""
    if start is None:
        start = datetime.utcnow() - timedelta(days=7)
    if end is None:
        end = datetime.utcnow()
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 
                    error_type,
                    COUNT(*)::int as count,
                    MAX(created_at) as last_seen
                FROM llm_usage
                WHERE created_at >= %s AND created_at <= %s AND status = 'error'
                GROUP BY error_type
                ORDER BY count DESC
            """, [start, end])
            
            return [
                ErrorSummary(
                    error_type=row["error_type"] or "Unknown",
                    count=row["count"],
                    last_seen=row["last_seen"],
                )
                for row in cur.fetchall()
            ]


@app.get("/api/recent")
async def get_recent_requests(
    limit: int = Query(default=50, ge=1, le=500),
    user_id: str | None = Query(default=None),
    model: str | None = Query(default=None),
    status: str | None = Query(default=None),
    pool=Depends(get_pool),
):
    """Get recent requests."""
    conditions = ["1=1"]
    params: list[Any] = []
    
    if user_id:
        conditions.append("user_id = %s")
        params.append(user_id)
    if model:
        conditions.append("model = %s")
        params.append(model)
    if status:
        conditions.append("status = %s")
        params.append(status)
    
    where_clause = " AND ".join(conditions)
    params.append(limit)
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute(f"""
                SELECT 
                    id,
                    created_at,
                    provider,
                    model,
                    user_id,
                    prompt_tokens,
                    completion_tokens,
                    (prompt_cost_cents + completion_cost_cents) / 100.0 as cost_usd,
                    duration_ms,
                    status,
                    error_type
                FROM llm_usage
                WHERE {where_clause}
                ORDER BY created_at DESC
                LIMIT %s
            """, params)
            
            return [dict(row) for row in cur.fetchall()]


@app.get("/api/stats/realtime")
async def get_realtime_stats(pool=Depends(get_pool)):
    """Get real-time stats for the last hour."""
    one_hour_ago = datetime.utcnow() - timedelta(hours=1)
    
    with pool.connection() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 
                    COUNT(*)::int as requests_last_hour,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as cost_last_hour,
                    COALESCE(AVG(duration_ms), 0) as avg_latency_ms,
                    COUNT(*) FILTER (WHERE status = 'error')::int as errors_last_hour
                FROM llm_usage
                WHERE created_at >= %s
            """, [one_hour_ago])
            
            row = cur.fetchone()
            
            # Get per-minute breakdown for sparkline
            cur.execute("""
                SELECT 
                    DATE_TRUNC('minute', created_at) as minute,
                    COUNT(*)::int as requests,
                    COALESCE(SUM(prompt_cost_cents + completion_cost_cents), 0) / 100.0 as cost
                FROM llm_usage
                WHERE created_at >= %s
                GROUP BY DATE_TRUNC('minute', created_at)
                ORDER BY minute ASC
            """, [one_hour_ago])
            
            minutes = [
                {"minute": r["minute"].isoformat(), "requests": r["requests"], "cost": float(r["cost"])}
                for r in cur.fetchall()
            ]
            
            return {
                "requests_last_hour": row["requests_last_hour"],
                "cost_last_hour": float(row["cost_last_hour"]),
                "avg_latency_ms": float(row["avg_latency_ms"]),
                "errors_last_hour": row["errors_last_hour"],
                "minutes": minutes,
            }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
